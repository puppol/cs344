Program 3 - Luke Puppo


How to Run:
  --> make
  --> smallsh

Make file is included. Simply run "make" and "smallsh" will appear.
Thank you!
